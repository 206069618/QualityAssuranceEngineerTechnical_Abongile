package testing.Pages;
import org.openqa.selenium.By;
public class TestPaths {
    public static String url() {return "https://www.way2automation.com/angularjs-protractor/webtables/";}
    public static By edit() {return By.xpath("/html/body/table/tbody/tr[1]/td[10]/button");}
    public static By AddUser() {return By.xpath("//*[text()=' Add User']");}
   // public static By Tabletd() {return By.ByCssSelector("td.smart-table-data-cell");}
    public static By FirstNameTxt() {return By.xpath("//*[@name='FirstName']");}
    public static By LastNameTxt() {return By.xpath("//*[@name='LastName']");}
    public static By UserNameTxt() {return By.xpath("//*[@name='UserName']");}
    public static By PasswordTxt() {return By.xpath("//*[@name='Password']");}
    public static By CompanyAAARdp() {return By.xpath("//tbody/tr[5]/td[2]/label[1]/input[1]");}
    public static By CompanyBBBRdp() {return By.xpath("//tbody/tr[5]/td[2]/label[2]/input[1]");}
       public static By RoleDrp() {return By.xpath("//*[@name='RoleId']");}
    public static By EmailTxt() {return By.xpath("//*[@name='Email']");}
    public static By MobilephoneTxt() {return By.xpath("//*[@name='Mobilephone']");}
    public static By SaveBtn() {return By.xpath("//*[text()='Save']");}
}
