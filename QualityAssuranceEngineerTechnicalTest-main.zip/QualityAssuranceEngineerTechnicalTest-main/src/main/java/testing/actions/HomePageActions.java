package testing.actions;

import core.Base;
import resources.Reporting;
import testing.Pages.TestPaths;

import java.security.SecureRandom;
import java.util.Random;

public class HomePageActions extends Base {
    public static void Home_Demo()
    {
        //navigate to the URL/Webpage
        if (!SeleniumExecutionInstance.Navigate(TestPaths.url())) {
             Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.url());
        }
        //checking the page is correct
        if (!SeleniumExecutionInstance.WaitForElement(TestPaths.edit())) {
             Reporting.TestFailed("Failed to click - "+ TestPaths.url());
        }
        //report Printing
        Reporting.StepPassed("successfully navigated to the Home/Demo Page");
       // Reporting.StepPassedWithScreenShot("Home/Demo Page");



    }
    public static void Add_User() {
        //navigate to the URL/Webpage


        if (!SeleniumExecutionInstance.ClickElement(TestPaths.AddUser())) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.AddUser());
        }
        Reporting.StepPassed("successfully navigated to the Home/Demo Page");

       // Reporting.StepPassedWithScreenShot("Home/Demo Page");



        // Generate and print 10 random numbers
        String randomFirstName = generateRandomString(15);
        String randomLastName = generateRandomString(15);
        String randomUserName = generateRandomString(8);
        String randomPassword = generateRandomString(8);





        // Enter the generated values
        if (!SeleniumExecutionInstance.EnterText(TestPaths.FirstNameTxt(), randomLastName)) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.FirstNameTxt());
        }
        if (!SeleniumExecutionInstance.EnterText(TestPaths.LastNameTxt(), randomUserName)) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.LastNameTxt());
        }
        if (!SeleniumExecutionInstance.EnterText(TestPaths.UserNameTxt(), randomUserName)) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.UserNameTxt());
        }
        if (!SeleniumExecutionInstance.EnterText(TestPaths.PasswordTxt(), randomPassword)) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.PasswordTxt());
        }
        if (!SeleniumExecutionInstance.ClickElement(TestPaths.CompanyAAARdp())) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.CompanyAAARdp());
        }
        if (!SeleniumExecutionInstance.ClickElement(TestPaths.CompanyBBBRdp())) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.CompanyBBBRdp());
        }
        if (!SeleniumExecutionInstance.selectOptionFromDropdown(TestPaths.RoleDrp(),"Sales Team")) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.CompanyBBBRdp());
        }

        if (!SeleniumExecutionInstance.EnterText(TestPaths.EmailTxt(), randomFirstName +"@gmail.com")) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.EmailTxt());
        }
        if (!SeleniumExecutionInstance.EnterText(TestPaths.MobilephoneTxt(), "1234454565")) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.MobilephoneTxt());
        }
        if (!SeleniumExecutionInstance.ClickElement(TestPaths.SaveBtn())) {
            Reporting.TestFailed("Failed to Navigate to -  " + TestPaths.SaveBtn());
        }
    }


    public static String One()
    {
        Home_Demo();

        return Reporting.finaliseTest();
    }
    private static String generateRandomString(int length) {
        // Define the characters allowed in the random string
        String allowedCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        // Create a secure random number generator
        SecureRandom random = new SecureRandom();

        // Build the random string
        StringBuilder randomStringBuilder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(allowedCharacters.length());
            char randomChar = allowedCharacters.charAt(randomIndex);
            randomStringBuilder.append(randomChar);
        }

        return randomStringBuilder.toString();
    }
}
