package resources;
import core.Base;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
public class WebTestDriver  extends Base {
    private WebDriver driver;
    public enum BrowserType {CHROME, FIREFOX}
    private BrowserType RunningBrowser;
    public static int PicCounter = 0;
    public WebTestDriver(BrowserType browser)
    {
        this.RunningBrowser = browser;
        LaunchBrowser();
    }
    public boolean LaunchBrowser()
    {

        switch (this.RunningBrowser)
        {
            case CHROME:
                String newDirectory = "C:\\Users\\x463528\\Documents\\QualityAssuranceEngineerTechnicalTest-main\\QualityAssuranceEngineerTechnicalTest-main\\chromedriver.exe";
                System.setProperty("user.dir", newDirectory);
                System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir"));
               // WebDriverManager.chromedriver().setup();
                ChromeOptions options = new ChromeOptions();
                // add Incognito parameter
                //                options.addArguments("--incognito");
                // DesiredCapabilities object
                DesiredCapabilities c = DesiredCapabilities.chrome();
                //set capability to browser
                c.setCapability(ChromeOptions.CAPABILITY, options);
//                  WebDriver driver = new ChromeDriver(o);
                //DesiredCapabilities dc = DesiredCapabilities.chrome();

//                  WebDriver driver = new ChromeDriver(options);
//                  driver.get("https://www.tutorialspoint.com/index.htm ");
                // dc.setPlatform(Platform.LINUX);
                //dc.setBrowserName("chrome");
                driver = new ChromeDriver(options);
                //driver = new RemoteWebDriver(new URL("http://zalenium-grid.mgmt.bpm.dev.za.omapps.net/wd/hub"), dc);

                driver.manage().deleteAllCookies();
               // wait = new WebDriverWait(driver, 20);
               // log.info("Chrome driver created");
                break;
            case FIREFOX:
                WebDriverManager.firefoxdriver().setup();
                this.driver = new FirefoxDriver();
            default:
                break;
        }

        this.driver.manage().window().maximize();

        return true;
    }
    public boolean shutDown ()
    {
        try
        {
            this.driver.close();
            this.driver.quit();
            return false;
        }
        catch (Exception e)
        {
            return false;
        }
    }
    public WebDriver getDriver()
    {
        return driver;
    }
    public boolean Navigate(String URL)
    {
        try
        {
            this.driver.navigate().to(URL);
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }
    public boolean WaitForElement(By selector)
    {
        boolean found = false;
        int counter = 0;
        try
        {
            while (!found && counter < 30)
            {
                try {
                    WebDriverWait wait = new WebDriverWait(this.driver, 1);
                    wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(selector));
                    found = true;
                }
                catch (Exception e)
                {
                    counter ++;
                    pause(1000);
                }
            }
            return found;
        }
        catch (Exception e)
        {
            return false;
        }
    }
    public boolean ClickElement(By selector)
    {
        try {
                WaitForElement(selector);

                WebDriverWait wait = new WebDriverWait(this.driver, 1);
                wait.until(ExpectedConditions.elementToBeClickable(selector));
                WebElement ClickElement = this.driver.findElement(selector);
                ClickElement.click();
                String ElementClicked = String.valueOf(selector);
            Reporting.StepPassedWithScreenShot("Element Clicked", ElementClicked);
                 return true;
            }
        catch (Exception e)
            {
                return false;

            }

    }
    public boolean selectOptionFromDropdown(By dropdownSelector, String optionText) {
        try {

            WebElement dropdownElement = this.driver.findElement(dropdownSelector);
            Select dropdown = new Select(dropdownElement);
            // Select the option by visible text
            dropdown.selectByVisibleText(optionText);
            String ElementClicked = String.valueOf(optionText);
            Reporting.StepPassedWithScreenShot("optionSelected",ElementClicked);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public boolean searchInTable(By selector, String searchText) {
        try {
            WebElement WElement = driver.findElement(selector);

            // Additional wait, if needed
            WebDriverWait wait = new WebDriverWait(this.driver, 1);
            wait.until(ExpectedConditions.visibilityOfElementLocated(selector));

            WebElement tableCell = this.driver.findElement(selector);

            if (tableCell.getText().equals(searchText)) {
                String ElementClicked = String.valueOf(searchText);
                Reporting.StepPassedWithScreenShot("test passed", ElementClicked);
                return true;
            } else {

                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
    public boolean ScrollToElement(By selector)
    {
        try {

            WebElement WElement = driver.findElement(selector);
            Actions action = new Actions(this.driver);
            action.moveToElement(WElement).perform();


            return true;
        }
        catch (Exception e)
        {
            return false;

        }

    }
    public boolean EnterText(By selector, String TextToBeEntered)
    {
        try {
            WaitForElement(selector);

            WebDriverWait wait = new WebDriverWait(this.driver, 1);
            wait.until(ExpectedConditions.elementToBeClickable(selector));
            WebElement TextElement = this.driver.findElement(selector);
            TextElement.sendKeys(TextToBeEntered);
            Reporting.StepPassedWithScreenShot("Text Entered", TextToBeEntered);
            return true;
        }
        catch (Exception e)
        {
            return false;

        }

    }
    public void pause (int millis) {
    try
    {
        Thread.sleep(millis);
    }
    catch (InterruptedException e)
    {
        e.printStackTrace();
    }
}
    public boolean ValidationElement(By selector, String TextToValidate)
    {
        try {
            WaitForElement(selector);
            WebDriverWait wait = new WebDriverWait(this.driver, 1);
            wait.until(ExpectedConditions.elementToBeClickable(selector));
            WebElement ValidationElement = this.driver.findElement(selector);

            return ValidationElement.getText().equals(TextToValidate);
        }
        catch (Exception e)
        {
            return false;
        }
    }
    public String takeScreenShot(boolean isError)
    {
        StringBuilder imageFilePathBuilder = new StringBuilder();
        StringBuilder relativePathBuilder = new StringBuilder();
        try
        {
            PicCounter++;
            imageFilePathBuilder.append(get_ReportDirectory());
            relativePathBuilder.append("ScreenShot\\");
            new File(imageFilePathBuilder.toString() + (relativePathBuilder).toString()).mkdir();
                relativePathBuilder.append(PicCounter+"_");
            if (isError)
            {
                relativePathBuilder.append("PASSED");
            }
            else
            {
                relativePathBuilder.append("FAILED");
            }

            relativePathBuilder.append(".png");
            File screenShot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenShot,new File(imageFilePathBuilder.append(relativePathBuilder).toString()));

            return "./"+relativePathBuilder.toString();
        }
        catch (Exception e)
        {
            return null;
        }
    }
    public void AlertHendler(){
        driver.switchTo().alert().accept();
    }
    public void SwitchTab(int ScrNo){
        driver.getWindowHandles();
        Set<String> handlesSet = driver.getWindowHandles();
        List<String> handlesList = new ArrayList<String>(handlesSet);
        driver.switchTo().window(handlesList.get(ScrNo));
    }
    public void CloseAndSwitchTab(){


            driver.close();
            SwitchTab(0);
                 }
}
