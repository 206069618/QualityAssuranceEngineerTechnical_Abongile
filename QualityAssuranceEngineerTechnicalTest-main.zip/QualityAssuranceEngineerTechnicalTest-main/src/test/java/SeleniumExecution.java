import core.Base;
import org.junit.*;
import org.junit.rules.TestName;
import resources.Reporting;
import resources.WebTestDriver;
import testing.actions.HomePageActions;



public class SeleniumExecution extends Base
{
                @Rule
                public TestName name = new TestName();

                @Before
                public void PreTest()
                {
                    TestName = name.getMethodName();
                    Reporting.createTest();
                    SeleniumExecutionInstance = new WebTestDriver(WebTestDriver.BrowserType.CHROME);
                }

                @Test
                public void Web()
                {
                    String Login = HomePageActions.One();
                    Assert.assertTrue("Unable to Complete Login Test"+ Login,Login == null);
                    HomePageActions.Add_User();
                    HomePageActions.One();
                    Assert.assertTrue("Unable to Complete Login Test"+ Login,Login == null);
                }
                @After
                public void PostTest()
                {
                    SeleniumExecutionInstance.shutDown();
                }

}
